package APITest;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import PageObjects.BookingPageObjects;
import Shared_Functions.Reusable_Functions;
//
public class CreateBooking extends Reusable_Functions{   
	//public ExtentReports extent;
	//public static ExtentTest Test; 
	  BookingPageObjects BookingPO;	    
	    WebDriver driver;	  

	   @BeforeTest
	    public void setup(){

	        //System.setProperty("webdriver.chrome.driver", driverPath);
		   Datapath=System.getProperty("user.dir");
		   System.out.println("Datapath is "+Datapath);
		    extent = new ExtentReports(Datapath+"\\Reports\\CreateBooking.html", true);
		    extent.loadConfig(new File(Datapath+"\\extent-config.xml"));
		   System.out.print("reched before booking");
		   System.setProperty("webdriver.chrome.driver",Datapath+"\\Drivers\\chromedriver.exe");
	        driver = new ChromeDriver();
	        //driver.get("chrome://settings/clearBrowserData");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        driver.get("https://www.qantas.com");	        
	        driver.manage().window().maximize();

	    }

	    /**

	     * This test go to http://qantas.com

	     * Enter the Booking Details on the search page

	     * Search for flights

	     * Complete the Booking

	     */
	   // Dataprovider provides 5 different testdata values
	   @DataProvider(name = "destination")
	    public Object[][] dataProviderMethod() {
	        return new Object[][] { { "PERTH",1 }, { "BRISBANE",2},
	        	{"MELBOURNE",3},{"DARWIN",4},{"CANBERRA",5} };
	    }

	   @Test(dataProvider="destination")	  
	    public void Booking_Flight(String Dest,int bags){

	        //Create Login Page object
		Test=extent.startTest("Booking with Destination City:"+Dest);
		
		System.out.print("reched booking");
	    BookingPO = new BookingPageObjects(driver);
	    try {
	    	Test.log(LogStatus.PASS,"Booking with Destination City:"+Dest + " ,Bags:"+bags);
		    BookingPO.SetBooking(Dest,bags);	    
		    extent.endTest(Test);
			extent.flush();
		    driver.close();
		    if(bags!=5)
		    {
			    driver = new ChromeDriver();
		        //driver.get("chrome://settings/clearBrowserData");
		        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		        driver.get("https://www.qantas.com");	        
		        driver.manage().window().maximize();
	        }
	    }catch(Exception e) {	    	
	    	System.out.print("Error Occured:"+e.getMessage());
	    	Test.log(LogStatus.FAIL,"Error Occured:"+e.getMessage());
	    }
	    

	    }
	   
	   @AfterTest
	   public void Teardown() throws Exception
	   {
		   extent.flush();
		   if(driver!=null)
			   driver.quit();
	   }

	}