package APITest;
import org.testng.annotations.Test;
import org.testng.annotations.*;
import org.testng.*;
import com.jayway.restassured.*;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.matcher.ResponseAwareMatcher;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ResponseBody;
import com.jayway.restassured.specification.RequestSpecification;

import org.junit.*;
import org.junit.runners.MethodSorters;
import static org.junit.Assert.assertTrue;
import java.util.Random;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import java.io.File;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.testng.IReporter;
import org.testng.IResultMap;
import org.testng.ISuite;
import org.testng.ISuiteResult;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.xml.XmlSuite;

public class PetTest {
	public ExtentReports extent;
	public static ExtentTest Test;    
	 RequestSpecification httpRequest;
	 ResponseBody body;
	 Response response;
	public static int petId=123;
	
	 @BeforeTest
	    public void setup (){
	        //Test Setup
		 System.out.println("Execution started");
		    extent = new ExtentReports("C:\\Users\\revan\\eclipse-workspace\\Assignment\\Reports\\PetTest.html", true);
		    extent.loadConfig(new File("C:\\Users\\revan\\eclipse-workspace\\Assignment\\extent-config.xml"));
	    
	   	  httpRequest = RestAssured.given();
	   	 System.out.println("End Before");
	    }
	
	@Test	(priority=1)
	public void GETPetId()
	{
		Test=extent.startTest("Get Pet ID");
		 RestAssured.baseURI = "https://petstore.swagger.io";
		 httpRequest = RestAssured.given();
		  response = httpRequest.get("/"+petId);	
		  if(response.getStatusCode()==200)
		  {
			  Test.log(LogStatus.PASS,"PET ID is working successfully");
		  }
		  else
		  {
			  Test.log(LogStatus.FAIL,"PET ID is NOT working with response:"+response.body());
		  }
		 body = response.getBody();	
		 System.out.println("Response Body is: " + body.asString());
		 extent.endTest(Test);
		 extent.flush();
		 
	}
	@Test(priority=2)
	public void updatePetname()
	{
		Test=extent.startTest("Update Pet Name");
		 RestAssured.baseURI = "https://petstore.swagger.io";
		 httpRequest = RestAssured.given();
		String jsonvalue = "{\r\n  \"id\": petId,\r\n  \"category\": {\r\n    \"id\": 0,\r\n    \"name\": \"string\"\r\n  },\r\n  \"name\": \"Testing\",\r\n  \"photoUrls\": [\r\n    \"string\"\r\n  ],\r\n  \"tags\": [\r\n    {\r\n      \"id\": 0,\r\n      \"name\": \"string\"\r\n    }\r\n  ],\r\n  \"status\": \"available\"\r\n}";
		httpRequest.contentType("application/json");
		httpRequest.content(jsonvalue);
		
		response= httpRequest.put("http://petstore.swagger.io/v2/pet");
		 System.out.println("Response Body is: " + body.asString());
		 if(response.getStatusCode()==200)
		  {
			  Test.log(LogStatus.PASS,"PET ID is working successfully");
		  }
		  else
		  {
			  Test.log(LogStatus.FAIL,"PET ID is NOT working with response:"+response.body());
		  }
		 extent.endTest(Test);
		 extent.flush();
	}
	@Test(priority=3)
	public void deletePetId()
	{
		Test=extent.startTest("Delete Pet Id");
		 RestAssured.baseURI = "https://petstore.swagger.io";
		 httpRequest = RestAssured.given();
		 response = httpRequest.delete("/"+petId);	 
		 body = response.getBody();	
		 System.out.println("Response Body is: " + body.asString());
		 if(response.getStatusCode()==200)
		  {
			  Test.log(LogStatus.PASS,"PET ID is working successfully");
		  }
		  else
		  {
			  Test.log(LogStatus.FAIL,"PET ID is NOT working with response:"+response.body());
		  }
		 extent.endTest(Test);
		 extent.flush();
	}
	@AfterTest
	public void Teardown()
	{
		extent.flush();
		extent.close();
	}
}
