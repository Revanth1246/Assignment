package APITest;

import java.io.File;

import org.testng.annotations.BeforeTest;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ResponseBody;
import com.jayway.restassured.specification.RequestSpecification;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.testng.annotations.Test;
import org.testng.annotations.*;
import org.testng.*;

import com.google.common.base.Stopwatch;
import com.jayway.restassured.*;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.matcher.ResponseAwareMatcher;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ResponseBody;
import com.jayway.restassured.specification.RequestSpecification;

import org.junit.*;
import org.junit.runners.MethodSorters;
import static org.junit.Assert.assertTrue;
import java.util.Random;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import java.io.File;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.testng.IReporter;
import org.testng.IResultMap;
import org.testng.ISuite;
import org.testng.ISuiteResult;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.xml.XmlSuite;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import java.util.Timer;

public class CreateID {
	public ExtentReports extent;
	public static ExtentTest Test;    
	 RequestSpecification httpRequest;
	 ResponseBody body;
	 Response response;
	 long totaltime=0,totaltimeinMs=0;
	 @BeforeTest
	    public void setup (){
	        //Test Setup
		 System.out.println("Execution started");
		    extent = new ExtentReports("C:\\Assignment\\Reports\\CreateID.html", true);
		    extent.loadConfig(new File("C:\\Assignment\\extent-config.xml"));
		   
	   	  httpRequest = RestAssured.given();
	   	 System.out.println("End Before");
	    }
	 @Test
	public void CreatePetIds()
	{
		 Test=extent.startTest("Create PetID");
		 Random rnd = new Random(System.currentTimeMillis());
		 int fail_counter=0;
		for(int i=0;i<20;i++)
		{
			Stopwatch started = Stopwatch.createStarted();
			int PetId_no=rnd.nextInt(900) + 100;
			 System.out.println("PetId_no value is :"+PetId_no);
			
			 RestAssured.baseURI = "https://petstore.swagger.io";
			 httpRequest = RestAssured.given();
			String jsonvalue = "{\r\n  \"id\": "+ PetId_no +",\r\n  \"category\": {\r\n   \"id\":"+ PetId_no +",\r\n    \"name\": \"string\"\r\n  },\r\n  \"name\": \"Testing\",\r\n  \"photoUrls\": [\r\n    \"string\"\r\n  ],\r\n  \"tags\": [\r\n    {\r\n      \"id\": 0,\r\n      \"name\": \"string\"\r\n    }\r\n  ],\r\n  \"status\": \"available\"\r\n}";
			httpRequest.contentType("application/json");
			httpRequest.content(jsonvalue);	
			
			response= httpRequest.post("http://petstore.swagger.io/v2/pet");
			 System.out.println("time is: " +response.getTimeIn(TimeUnit.SECONDS));
			 System.out.println("getStatusCode is: " + response.getStatusCode());
			totaltime=totaltime+response.getTimeIn(TimeUnit.SECONDS);
			totaltimeinMs=totaltimeinMs+response.getTimeIn(TimeUnit.MILLISECONDS);
			if(response.getStatusCode()==200)
			  {
				  Test.log(LogStatus.PASS,PetId_no+" :Pet ID is working successfully");
			  }
			  else
			  {
				  fail_counter=fail_counter+1;
				  Test.log(LogStatus.FAIL,PetId_no+" : PET ID is NOT working correctly:"+response.body());
			  }
			
		}
		//validating the total time>20
		if(totaltime>10)
		{
			Test.log(LogStatus.FAIL,"Total time taken for 20 pets is :"+totaltime);

		}
		else
		{
			Test.log(LogStatus.PASS,"Total time taken for 20 pets is :"+totaltime);
		}
		
		//Validating the Fail counter
		
		if(fail_counter>1)
		{
			Test.log(LogStatus.FAIL,"Total Failed Status code count exceeds than 1 which is :"+fail_counter);

		}
		else
		{
			Test.log(LogStatus.PASS,"Total Failed Status code value is lessthan 2 :"+fail_counter);
		}
		
		//Average of the total pets
		
		if((totaltimeinMs/20)>300)
		{
			Test.log(LogStatus.FAIL,"Average Response time >300ms :"+totaltimeinMs);

		}
		else
		{
			Test.log(LogStatus.PASS,"Average Response time < 300ms :"+totaltimeinMs);
		}
		
	}
	@AfterTest
	 public void Teardown()
	 {
		 extent.endTest(Test);
		 extent.flush();
		 extent.close();
	 }

}
