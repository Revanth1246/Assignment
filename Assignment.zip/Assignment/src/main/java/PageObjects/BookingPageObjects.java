package PageObjects;

import java.awt.AWTException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import Shared_Functions.Reusable_Functions;

//import Shared_Functions.Shared_Functions;

public class BookingPageObjects extends Reusable_Functions{
	WebDriver driver;
	Reusable_Functions RF;
	
//************************************
//*****	Page Objects Declarations *****
//*************************************
	
	//Home Page
	
	@FindBy(xpath="//a[text()='Book ']")
	WebElement Book_Menu_Link;
	
	@FindBy(xpath="//*[text()='Log in']")
	WebElement login;
	
	@FindBy(className="css-su611k-runway-dropdown__button-svg")
	
	WebElement Return_dropdown;
	
	  @FindBy(xpath="//*[text()='One way']")

	    WebElement Oneway_dropdown;

    @FindBy(xpath="//*[text()='Where to?']")

    WebElement Destination_Where;

    @FindBy(xpath="//input[@aria-labelledby='downshift-0-label']")

    WebElement Destination_inputbox;    

    @FindBy(xpath="//*[text()='Fly when?']")

    WebElement FlyDate;

    @FindBy(xpath="//*[text()='SEARCH FLIGHTS']")

    WebElement Flights_Search_button;
    
    
    //FLy date page
    
    @FindBys(@FindBy(xpath="//button[text()='Confirm']"))
    
    List<WebElement> Fly_Date_Confirm;
    
    
    // Flights_Total
 @FindBys(@FindBy(xpath="//div[@class='price-table']/cart-subtotal-row/span[1]"))
    
    List<WebElement> Total_price;
 
 
 // Flights Selection
 @FindBys(@FindBy(xpath="//span[@class='amount cash ng-star-inserted']"))
 
 List<WebElement> Flight_Selection;
 
 //Addto Trip button
 
 @FindBy(xpath="//span[text()='Add to Trip']")
 WebElement Add_to_trip_button;

 @FindBy(xpath="//div[@class='amount-per-bound e2e-cash-amount ng-tns-c7-62 ng-star-inserted']")
 WebElement Final_Price;
 
 @FindBy(xpath="//span[text()='Continue']")
 WebElement Continue_button;
 
 @FindBy(xpath="//span[text()='Accept']")
 WebElement Accept_button;
 
 @FindBy(xpath="//*[text()='Add bags']")
 WebElement Add_button;
 
 @FindBy(xpath="//button[@aria-label='Add additional bag']")
 WebElement Add_bag_button;

 @FindBy(xpath="//*[text()='Change this flight']")
 WebElement Change_Flight;
    
//************************************
//*****	Page Factory Initialization *****
//*************************************
    public BookingPageObjects(WebDriver driver){

        this.driver = driver;

        //This initElements method will create all WebElements

        PageFactory.initElements(driver, this);
        System.out.println("Completed Init");
        

    }
  //************************************
  //***** Methods Declaration *****
  //*************************************
    
    public void SetBooking(String Destination,int bags) throws InterruptedException, AWTException
    {
    	
    	//this.driver=SF.driver;
    	   System.out.print("reched SetBooking");
    	//Wait for the Rundropdown
    	  
    	   System.out.print("reched Webdriver wait");
   		WebDriverWait wait = new WebDriverWait(driver, 200);
   		wait.until(ExpectedConditions.visibilityOf(login));
   		Thread.sleep(2000);
  	    System.out.print("login displayed fine");  	 	 
      Reusable_Functions.Scroll_down(driver);
  	  Thread.sleep(500); 
  	   
  	  Destination_Where.click();
   		Thread.sleep(1000);
   		
   		Reusable_Functions.Scroll_down(driver);
   		Thread.sleep(2000);
   		Return_dropdown.click();
   		Thread.sleep(2000);
   		Oneway_dropdown.click();
   	    Test.log(LogStatus.PASS,"Clicked One-way Journey");
   		Thread.sleep(2000);
   		Destination_Where.click();
   		Thread.sleep(1000);
   		Reusable_Functions.Webdriver_Wait(Return_dropdown, driver);
   		System.out.print("dropdown vsible");
   		Destination_inputbox.sendKeys(Destination);
   		Thread.sleep(3000);   
   		Destination_inputbox.sendKeys(Keys.RETURN);
   		System.out.print("dropdown Entered keys");
   	   Test.log(LogStatus.PASS,"Selected Destination:"+Destination);
   		Reusable_Functions.Webdriver_Wait(FlyDate, driver);
   		FlyDate.click();
   		String Fly_Date1=null;
   		//Calculating the date
   		try {
   		String date=Reusable_Functions.GetDate("MMM dd");
   		System.out.println("date is "+date);
   		String[] date_value=date.split(" ");
   		int i = Integer.parseInt(date_value[1]);
   		i=i+1;
   		Fly_Date1=date_value[0] +" "+ i;  /// Always Selects the next date from today
   		System.out.println("Fly_Date is "+Fly_Date1);
   	    Test.log(LogStatus.PASS,"Selected Flying Date as :"+Fly_Date1);
   		}catch(Exception e)
   		{
   			System.out.println("Error on Date:"+e.getLocalizedMessage());
   			Test.log(LogStatus.FAIL,"Error on Date:"+e.getLocalizedMessage());
   		}
   		Thread.sleep(2000);
   		//Entering Date
   		WebElement element=driver.findElement(By.xpath("//*[contains(@aria-label,'"+Fly_Date1+"')]"));
   		element.click();
   		Thread.sleep(2000);
   		Fly_Date_Confirm.get(0).click();
   		Reusable_Functions.Webdriver_Wait(Flights_Search_button, driver);
   		Flights_Search_button.click();
   		System.out.print("reched dropdown");
   		Reusable_Functions.Webdriver_Wait(Flight_Selection.get(0), driver);
   		String price=Reusable_Functions.Get_Text(Total_price.get(0), driver);
   		System.out.print("Total price is "+price); 
   		price=price.replace(" ", "");
   		Assert.assertEquals(price, "$0");
   		if(price.replaceAll("\\s+","").equalsIgnoreCase("$0"))    		   // this will also take care of spaces like tabs etc.
   		
   		{
   		 Test.log(LogStatus.PASS,"Cart Value is Matching the Expected value as $0");
   		}
   		else
   		{
   		 Test.log(LogStatus.FAIL,"Cart Value:"+price+" is NOT Matching the Expected value as $0");
   		}
        //Select the Flights
   	    Reusable_Functions.Scroll_down(driver);
   	    Thread.sleep(3000);
   	    String Final_price=Reusable_Functions.Get_Text(Flight_Selection.get(0), driver);
		System.out.print("Final price is "+price); 
		 Test.log(LogStatus.PASS,"Selected the Flight with the price value:"+Final_price);
		Reusable_Functions.Scroll_To_Element(Flight_Selection.get(0), driver);
		  Thread.sleep(3000);
   		Flight_Selection.get(0).click();
   	  Thread.sleep(2000);
   		Reusable_Functions.Webdriver_Wait(Add_to_trip_button, driver);   	      	
   		Add_to_trip_button.click();
   		Reusable_Functions.Webdriver_Wait(Continue_button, driver);
   	   String Cart_displayed_price=Reusable_Functions.Get_Text(Total_price.get(0), driver);
	    System.out.print("Cart_displayed_price price is "+Cart_displayed_price);
		Assert.assertEquals(Final_price+"*", Cart_displayed_price);
		Cart_displayed_price=Cart_displayed_price.replace("*","");
	    if(Final_price.toLowerCase().trim()==Cart_displayed_price.toLowerCase().trim())
	    	if(Final_price.replaceAll("\\s+","").equalsIgnoreCase(Cart_displayed_price.replaceAll("\\s+",""))) 
	        {
	   		 Test.log(LogStatus.PASS,"Cart Value is Matching the Expected value as "+Cart_displayed_price);
	   		}
	   		else
	   		{
	   		 Test.log(LogStatus.FAIL,"Cart Value:"+Final_price+" is NOT Matching the Expected Cart_displayed_price as:"+Cart_displayed_price);
	   		}
		Thread.sleep(2000);
   		Continue_button.click();
   	 System.out.print("Continue cliked");
   		Thread.sleep(10000);
   		Reusable_Functions.Webdriver_Wait(Change_Flight, driver);
   	 System.out.print("Continue cliked1");
   	Reusable_Functions.Webdriver_Wait(Continue_button, driver);
   		Thread.sleep(4000);
    	 System.out.print("Continue cliked2");
    	 Reusable_Functions.Javascript_Click(Continue_button, driver);
   	 System.out.print("Continue cliked2");
   		Reusable_Functions.Webdriver_Wait(Accept_button, driver);
   		Accept_button.click();
   		Thread.sleep(10000);
   		Reusable_Functions.Webdriver_Wait(Add_button, driver);
   		Reusable_Functions.Scroll_down(driver);
   		Thread.sleep(4000);
   		Reusable_Functions.Javascript_Scroll(Add_button, driver);
   		Thread.sleep(4000);
   		Add_button.click();
   		Reusable_Functions.Webdriver_Wait(Add_bag_button, driver);
   	   
   		for(int bag_count=2;bag_count<=bags;bag_count++)
   		{
   			Add_bag_button.click();
   			Thread.sleep(2000);
   		}
   		Test.log(LogStatus.PASS,"Added no of bags"+bags + " successfully");
   		
    }
    

}
