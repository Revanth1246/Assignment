package Shared_Functions;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class Reusable_Functions {
	public static ExtentReports extent;
	public static ExtentTest Test; 
	public static String Datapath;
	//public static WebDriver driver;
	public static String GetDate(String Format)
	{
		System.out.println("Get Date Shared Function");		
		 DateTimeFormatter dtf = DateTimeFormatter.ofPattern(Format);
		   LocalDateTime now = LocalDateTime.now();
		   System.out.println(dtf.format(now));
		   return dtf.format(now).toString();
	}
	public static void Webdriver_Wait(WebElement element,WebDriver driver)
	{
		WebDriverWait wait = new WebDriverWait(driver, 200);
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	public static String Get_Text(WebElement element,WebDriver driver)
	{
		Webdriver_Wait(element,driver);
		return element.getText();	
		
	}
	public static void Click_Element(WebElement element,WebDriver driver)
	{
		Webdriver_Wait(element,driver);
		element.click();	
		
	}
	public static void SendKeys(WebElement element,WebDriver driver,String value)
	{
		Webdriver_Wait(element,driver);
		element.sendKeys(value);
		
	}
	public static void Javascript_Click(WebElement element,WebDriver driver)
	{
		
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);
	}
	public static void Javascript_Scroll(WebElement element,WebDriver driver)
	{
		WebElement element1=element;
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();", element1);
	}
	public static void Scroll_down(WebDriver driver) throws InterruptedException
	{
		 JavascriptExecutor js = (JavascriptExecutor) driver;
	      js.executeScript("javascript:window.scrollBy(250,350)");
	      Thread.sleep(1000);
	}
	
	public static void Scroll_To_Element(WebElement element,WebDriver driver) throws InterruptedException
	{
		//WebElement element = driver.findElement(By.id("my-id"));
		Webdriver_Wait(element,driver);
		Actions actions = new Actions(driver);
		actions.moveToElement(element);
		actions.perform();
		Thread.sleep(200);
	}
}
