File format is in .swf. please open in players like 
VLC Media player for best viewing.